import pandas as pd
import matplotlib.pyplot as plt
from IPython.display import HTML
from matplotlib.animation import FuncAnimation

def animate2(i):
    dfa = pd.read_csv(r'C:\Users\eric\Desktop\step4\src\data110.txt')
    x = dfa.x
    y1 = dfa.y1
    y2 = dfa.y2
    y3 = dfa.y3
    plt.cla()
    plt.plot(x,y1,label='APPL')
    plt.plot(x,y2,label='GOOGL')
    plt.plot(x,y3,label='AWS')
    plt.legend(loc='upper left')

ani2 = FuncAnimation(plt.gcf(),animate2,interval=300)
plt.show()