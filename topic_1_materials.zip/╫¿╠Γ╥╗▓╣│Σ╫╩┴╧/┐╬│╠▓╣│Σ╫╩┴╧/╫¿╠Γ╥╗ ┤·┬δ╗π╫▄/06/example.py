# str1='hello'
# str2='world'
# print (str1+ ' ' + str2)
# str1='hello '
# print(str1 + str1+ str1)
# print(str1 * 3)
# print ('=='*50)
#
# str3='Mars老师'
#
# print ('MarsW' in str3)
# print(dir(list))
#
# print(help(list.pop))
str1='123'
str2='abc'
str3='12ab'
print(str1.isdigit())
print(str2.isdigit())
print(str3.isdigit())

print('=='*40)
str1='123'
str2='abc'
str3='Mars老师'
print(str1.isalpha())
print(str2.isalpha())
print(str3.isalpha())
str1='hello world !!!'
print (str1.split())
print (",".join(str1.split()))

print(help(format))
print('=='*40)
print("{} {}".format("hello","world"))
print("{} {} {}".format("hello","world","!!!!"))

print("{0} {1} {0}".format("hello","world","!!!!"))





