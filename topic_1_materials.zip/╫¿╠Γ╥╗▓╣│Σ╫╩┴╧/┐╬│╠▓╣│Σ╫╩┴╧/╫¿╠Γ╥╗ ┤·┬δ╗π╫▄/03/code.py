# print (5+5)
# a = 5
# b = 5
# print (a+b)
# print (a + 7)
# a = 5
# a += 7
# print ( a )
# a = 5
# a -= 3
# print ( a )
#
# a = 5
# a *= 3
# print ( a )

#
# print (5/2)
#
# print (5//2)
#
# print ( 50 % 2)
#
# print( 3*2)
# print( 3**3)

# print (10 % -3)
# print (-10 % 3)
# print ( -10 % -3)
#
# print (10 // -3 )
# print (-10 // 3)

# print(((-4) *2) +(5 / (-2)) -4)
#
# print(((((-4) *2) +5) / (-2)) -4)
# print (100)
#
# print (5)
# print (bin(14))
# print (bin(100))
#
#
#
# print (14)
# print (hex(14))
#
#
# print (0xe)
#
# print (oct(14))
#
# print(0o16)
import math
print (math.pi)

print(a)