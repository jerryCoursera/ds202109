import operator

dict1 = {}
dict2 ={'key1':30,'key2':50,'key3':100}
print(dict2)
print (dict2['key1'])

dict2 ={'key1':30,'key2':50,'key3':100}
print(dict2)
print(len(dict2))
print('**'*50)
print(dict2)
dict2['key1']=150
print(dict2)
print (dict2['key1'])
# print (dict2['key4'])
dict2['key4']=450
print (dict2['key4'])
print(dict2)
del dict2['key4']
print(dict2)
del dict2
# print(dict2)
print('**'*50)
dict1 ={'key1':30,'key2':50,'key3':100}
dict2 ={'key3':100,'key2':50,'key1':30}
# print (cmp(dict1,dict2))
print (operator.eq(dict1,dict2))
dict3 = dict1.copy()
print(dict3)
print (dict1.keys())
print (dict1.values())
list1 = ['key1', 'key2', 'key3']
list2= [30, 50, 100]
dict4 = dict.fromkeys(list1,list2)
print(dict4)
print (dict(zip(list1,list2)))
# print (dict4['key4'])
print (dict4.get('key4',"key4 not exist"))
print ('key4' in dict4)
print('**'*50)
str=input("请输入你的信息")
print (str)

