
var01= int(input("请输入需要的位数"))
def fab(a):
    n1 = 0
    n2 = 1
    list1 = [0, 1]
    count=2
    while count < a:
        print (count)
        count +=1
        nth = n1 + n2
        list1.append(nth)
        n1 =n2
        n2=nth
    return list1
print (fab(var01))
list2=[]
list2=fab(var01)
print(list2)
print(list2[11])

