# a =5.
# b =6
# c = "hello world"
# print(type(a))
# print(type(c))
#
# print (a+b)
# print (type(a+b))
#
# import keyword
# print (keyword.kwlist)
#
# print (keyword.iskeyword('break'))
#
# print(c)
# a = 5.0
# print (a)
# print (type(a))
# print (type(int(a)))
# print (int(a))
# print (type(str(a)))
# print (str(a))
c = "hello world"
# print (type(int(c)))
# print (int(c))
print(c)
d = r"c:\new\new\new\new\new\new\new\new\new\new\new"
print(d)
e = r"""c:\new\new\new\new\new\new\new

\new\new\new\new
"""
print(e)


print(c)
print(len(e))
f="欢迎您！！\""
print(len(f))
print((f))
g="6"
print (type(g))
print (int(g))



