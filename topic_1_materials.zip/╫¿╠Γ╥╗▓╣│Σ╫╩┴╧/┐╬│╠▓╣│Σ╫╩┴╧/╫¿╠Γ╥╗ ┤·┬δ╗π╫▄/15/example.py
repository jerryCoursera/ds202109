try:
    # x = 5 /0
    # x = x+5
    # open('abc.txt','r')
    # x = 10
    # assert  x < 0
    # list1=[1,2,3]
    # print (list1[9])
    raise FileNotFoundError('python')
except NameError  :
    print ("出现错误 变量未定义")
except ZeroDivisionError:
    print("出现错误 分母为0")
except FileNotFoundError:
    print("出现错误 没有找到需要的文件")
except AssertionError:
    print("出现错误 assert评估错误")
except IndexError:
    print("出现错误 索引越界")

finally:
    print ("程序结束")
# x = x+5