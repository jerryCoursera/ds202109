def square(x):
    return  x*x

print ( square(12))

print ((lambda a : a*a) (10))


print ((lambda a , b : a*b) (10,90))

print ((lambda a , b=90 : a*b) (10))

print ((lambda *c: sum(c)) (10,90,101,9999,111,222))

print ((lambda **c: sum(c.values())) (a=2,b=4,c=7))

x=lambda a , b : a*b

print (x(5,6))

def foo():
    return lambda a , b : a*b

print ((foo()) (5,6))

print('*'* 60)

list1=[1,2,3,4]

sum01=0
for i in list1:
    sum01 +=i
print (sum01)

def add(x):
    return x*10

result = map(add,list1)
print (list(result))

result2 = map(lambda x: x*30,list1)
print (list(result2))
from  functools  import  reduce
result3= reduce(lambda x,y : x+y,list1)
print (result3)

fib = [0,1,1,2,3,5,8,13,21,34,55]
list3=[]
for i in fib:
    if i % 2 == 0:
        list3.append(i)
print (list3)


print (list(filter(lambda x : x % 2 ==0,fib)))

print('*'* 60)











