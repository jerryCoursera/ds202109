#DF数据格式切换
#单句执行alt+shift+E
import pandas as pd
data1 = pd.read_csv('simple_data.csv')
def trans(x):
    if isinstance(x,float)& (not pd.isna(x) ):
        x = int(x)
    return x
new_data1 = data1.applymap(trans)
print(new_data1)


#如何使用数据作为marker标记显示在图里
import matplotlib.pyplot as plt
y1 = data1.loc[data1['Player']=='LeBron James']
y2 = data1.loc[data1['Player']=='Kevin Durant']
a1 = y1['AST'].reset_index(drop = True)
a2 = y2['AST']
plt.plot(range(8),a1[:8],marker = 'x')
plt.plot(range(8),a2[:8],marker = 'v')
#显示数值
for i in range(8):
    plt.text(i,a1[i]+0.5,a1[i])

plt.show()

#
plt.stackplot(range(8),a1[:8],a2[:8])
plt.show()

#rotation
data2 = pd.read_csv('Seasons_Stats.csv')
new_data2 = data2.tail(15)
pts = new_data2['PTS']
print(pts)
players = new_data2['Player']
print(players)
plt.bar(players,pts)
#ctrl+鼠标左键点击方法名
plt.xticks(rotation  = 45)
# plt.xlabel('name',rotation =45 )
plt.yticks(rotation = 15)
plt.legend()
plt.show()

#df.plot 和 matplotlib plot
new_data2.plot(x = 'Player',kind = 'bar')

column  = ['a','b','c']
a1 = ['tom',300,400]
a2 = ['jerry',20,30]
df = pd.DataFrame([a1,a2],columns = column)
print(df)
df.plot(x = 'a' ,kind = 'bar')


#数据可视化
#——》基于数据画图
#折线图：体现数据的变化规律，通常是针对同一个体，更多基于连续性维度（例如，时间）的变化趋势（波动）
#柱状图：体现的是不同个体之间的对比,更多的是基于离散维度（不同的人，不同的产品）
#直方图：体现的基于连续维度统计变化趋势,(bin!)
print(data2)
d2 = data2.loc[data2['Year'] == 2016]
ages = d2['Age']
print(ages)
bins = [0,20,25,28,30,35,40]
plt.hist(ages,bins,edgecolor = 'black')
plt.show()
#饼状图,不同分类所占比例（所有分类）
#散点图，体现数据（分布！）趋势，重点看散点位于的位置，位于不同位置的散点属于什么类别（用颜色，或者是点的大小）
#基于地图展示数据————》热力图：记数，用颜色表示数值大小，把颜色画到地图（热力图）上，直观！好看!高级！
#数据可视化——》一眼就能看出数据的特征
