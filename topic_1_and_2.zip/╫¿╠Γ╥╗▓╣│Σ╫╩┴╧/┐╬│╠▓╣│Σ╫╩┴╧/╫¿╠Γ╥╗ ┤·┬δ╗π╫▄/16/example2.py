
def prime1(upper):
    try:
        num = []
        for i in range(2,int(upper)):
            j = 2
            for j in range (2,i):
                if (i % j ==0):
                    break
            else:
                num.append(i)
    except :
        print ("输入数据有问题")
    return num
print(prime1('100a'))




