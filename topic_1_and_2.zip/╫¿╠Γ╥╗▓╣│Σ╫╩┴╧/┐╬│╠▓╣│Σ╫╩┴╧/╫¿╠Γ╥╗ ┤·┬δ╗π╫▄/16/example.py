# # var1 ="mars"
# # print( var1)
#
# def print_hello():
#     print ("mars")
#
# for i in range(4):
#     print_hello()

def func1(a,b):
    if a ==b:
        print("猜对了")
    else:
        print("猜错了")

func1(20,40)

