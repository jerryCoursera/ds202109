import re
# print ('hello world')

print (re.match('hello','hello world'))

print (re.match('world','hello world'))

print (re.search('hello','hello world'))

print (re.search('world','hello world'))

str1='13399887766'
print (re.match('\d*',str1))
print (re.match('\d*',str1).start())
print (re.match('\d*',str1).end())

str2='Cuuttt is smarter than dog'
r = re.match('[a-zA-Z]* is smarter than dog',str2)
print (r)

r = re.match('.* is smarter than dog',str2)
print (r)

str3='Mars123@163.com'

r = re.match('(.*)@(\d{3}.com)',str3)
print (r)
print (r.group())
print (r.group(1))
print (r.group(2))

str2='Cat is smarter than dog'

r = re.match('(.*) is smarter than (.*)',str2)
print (r)
print (r.group())
print (r.group(1))
print (r.group(2))

str5=189-9988-7766
r = re.match('1[2389]\d{1}-\d{4}-\d{4}',str5)