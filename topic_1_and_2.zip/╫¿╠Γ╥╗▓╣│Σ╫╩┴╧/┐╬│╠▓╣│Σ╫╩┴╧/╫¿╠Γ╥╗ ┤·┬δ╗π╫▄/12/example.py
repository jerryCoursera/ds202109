list1 = ['2www', 'abcd', '5com']

for i in list1:
    print (i)

for i in range(5):
    print (i)

song = """When I am down and oh my soul so weary When troubles come and my heart burdened be Then I am still and wait here in the silence Until you come and sit awhile with me You raise me up so I can stand on mountains You raise me up to walk on stormy seas I am strong when I am on your shoulders You raise me up to more than I can be You raise me up so I can stand on mountains You raise me up to walk on stormy seas I am strong when I am on your shoulders You raise me up to more than I can be You raise me up, so I can stand on mountains
"""

print (type(song))
list2 = song.split(' ')
print (list2)
print (len(list2))

dict1={}

dict1 = dict.fromkeys(list2,0)
print (dict1)

from collections import Counter

print( Counter(list2).keys())
print( Counter(list2).values())
print( Counter(list2).most_common(3))

d = {'book': ['python', 'datascience'], 'author':'laoqi', 'publisher':'phei'}
list1 = d.keys()
list2 = d.values()
print (list1)
print(list2)

print (dict(zip(list2,list1)))








