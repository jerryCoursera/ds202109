# a =5.
# b =6
# c = "hello world"
# print(type(a))
# print(type(c))
#
# print (a+b)
# print (type(a+b))
#
# import keyword
# print (keyword.kwlist)
#
# print (keyword.iskeyword('break'))
#
# print(c)
# a = 5.0
# print (a)
# print (type(a))
# print (type(int(a)))
# print (int(a))
# print (type(str(a)))
# print (str(a))
c = "hello world"
# print (type(int(c)))
# print (int(c))
print(c)

print (c[0:19:3])

print (c[-11:-6])