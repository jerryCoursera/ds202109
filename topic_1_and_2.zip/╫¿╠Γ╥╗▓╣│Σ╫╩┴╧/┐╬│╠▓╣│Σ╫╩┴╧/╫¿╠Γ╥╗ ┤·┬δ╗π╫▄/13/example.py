# # c=0
# # while c< 5:
# #     print("hello world")
# #     c += 1
#
# # ****
# # ****
# # ****
# # ****
# # for i in range(4):
# #     print ('*'*(i+1))
#
# # *
# # **
# # ***
# # ****
# # for i in range(4):
# #     print ('*'*(i+1))
#
# # 1 * 1 = 1
# # 1 * 2 = 2 2 * 2 = 4
# # 1 * 3 = 3 2 * 3 = 6 3 * 3 = 9
#
# # 1 * 1
# # 1 * 2  2 * 2
# # 1 * 3  2 * 3  3 * 3
# print ('*'* 50)
# row = 1
# while row <= 9:
#     col = 1
#     while col <= row :
#         print ('{} * {} = {}  '.format(col,row,row*col),end='')
#         col += 1
#     print ('' )
#     row +=1
#
# print ('*'* 50)
# num =5
# while True:
#     y = int(input("请输入相关的数据"))
#
#     if y == num:
#         print ("猜对了")
#         break
#     elif y > num:
#         print ("猜错了, 猜的数字偏大")
#     else:
#         print("猜错了, 猜的数字偏小")
#
# print ("猜对了 ----  程序结束")
#
#
import random
print (random.randint(0,100))