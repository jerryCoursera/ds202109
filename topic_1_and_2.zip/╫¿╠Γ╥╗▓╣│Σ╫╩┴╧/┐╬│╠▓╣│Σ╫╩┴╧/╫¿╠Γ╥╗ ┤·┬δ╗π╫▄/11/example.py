if 0:
    print ('right')
print('finish')
print ("*"*50)
a = 9
r = a % 2
if r == 0:
    print ("偶数")
else:
    print ("奇数")

a = 'www.abcd.com'
list1 = a.split('.')
print(list1)
if (list1[0]=='www'):
    print ("满足第一个要求")
    if (len(list1[1])==4):
        print ("满足第二个要求")
        if (len(list1[2]) == 3):
            print("满足第三个要求")
else:
    print ("网址无效")
print("*" * 50)
a = '2www.abcd.5com'
list1 = a.split('.')
print(list1)
if (list1[0]=='www') or (len(list1[1])==4) and (len(list1[2]) == 3):
    print ("满足第一个第二个第三个要求")

else:
    print ("网址无效")