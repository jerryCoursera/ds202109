# a= "hello world"
#
# def foo():pass
#
# print (id(a))
# print (id(foo))
# print (id(foo()))
# print (id(foo()))
# print(a)
# print(foo)
# print(foo())
#
# print('*'*50)
# name="Mars老师"
# def changeName():
#     name="Eric"
#     print ("修改成名字{}".format(name))
#
#     def changeName2():
#         nonlocal  name
#         print(name)
#         name = "Peter"
#         print("修改成名字{}".format(name))
#
#     changeName2()
# print (name)
# print (changeName())
# print (name)

print("*"*50)
def foo():
    print('foo')
foo()

import time
# def foo():
#     start =time.clock()
#     print('foo')
#     time.sleep(0.3)
#     end = time.clock()
#     print ("时间差是", str(end-start))

foo()

def timeit(f):
    def wrapper():
        start = time.clock()
        f()
        time.sleep(0.3)
        end = time.clock()
        print ("时间差是", str(end-start))
    return wrapper

foo()
@timeit
def foo():
    print('foo')


foo()