a =10
b = 40
print (a==b)
print (a!=b)
print (a>=b)
print ("*"* 50)
set1 = [1,2,3,4,5,6,1,2,3]
print (set1)
set2 = {1,2,3,4,5,6,1,2,3}
print (set2)
print ("*"* 50)
seta= {1,2,3,4,5,6,7,8}
setb= {10,11,3,4,5,6,7,8}

a = seta.intersection(setb)
print (a)

print (seta & setb)

b = seta.union(setb)
print (b)

print (seta | setb)

print (seta-setb)
print (setb-seta)
print ("*"* 50)
a = [1,2,3,4,5]
b = a
print(a)
print ("a 在计算机存储器中的信息地址是 {}".format( id(a)))
print (b)
print ("b 在计算机存储器中的信息地址是 {}".format( id(b)))
b = a.copy()
print(a)
print ("a 在计算机存储器中的信息地址是 {}".format( id(a)))
print (b)
print ("b 在计算机存储器中的信息地址是 {}".format( id(b)))

