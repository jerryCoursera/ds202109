def add(a,b):
    c=(a+b)
    return c,a,b

print(add(10,20))
print("*"* 50)

def add2(a,b=100):
    c=(a+b)
    return c

def add3(a,b,*d):
    c=(a+b)
    print ("参数1是{}".format(a))
    print("参数2是{}".format(b))
    for i in range(len(d)):
        print("参数3是%s" % d[i])
    return c

print(add3(90,10,100,200,300,500))

x, *y = 1, 2, 3, 4 ,5,6
print(x)
print(y)

def add4(a,b,**d):
    c=(a+b)
    print ("参数1是{}".format(a))
    print("参数2是{}".format(b))
    for i in d:
        print("参数3是%s" % i)
        print("参数3是%s" % d[i])
    return c

print(add4(90,10,k=100,d=200,e=300))