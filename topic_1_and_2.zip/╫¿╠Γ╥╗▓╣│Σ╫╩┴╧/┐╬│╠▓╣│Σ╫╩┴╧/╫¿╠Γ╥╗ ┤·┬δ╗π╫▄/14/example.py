print (range(6))

print ({ i:i for i in range(1,6) })

dict1={}
for i in range(1,6):
    dict1[i]=i
print (dict1)

dict1={}
for i in range(1,6):
    if i % 2 == 0:
        continue
    dict1[i]=i
print (dict1)

print ({ str(i):i for i in range(1,6) if i % 2 == 1 })

print ('*'* 50)
data = {
      "id": 1,
      "first_name": "Jonathan",
      "middle_name": None,
      "last_name": "Hsu"
    }

data = {
      "id": 1,
      "first_name": "Jonathan",
      "middle_name": None,
      "last_name": "Hsu"
    }

# print (data)
# del data['middle_name']
# print (data)

print (type(data.keys()))

for i in list(data.keys()):
    # print ("打印内容")
    if not data[i] :
        print (i)
        print ("当前值为空")
        del data[i]
print (data)

print ('*'* 50)

data = {
  "first_name": "Jonathan",
  "last_name": "Hsu"
}
for i in data.keys():
    print (data[i].upper())
    data[i]= data[i].upper()
print(data)

print ('*'* 50)
d1 = {"a":1, "b":2}
d2 = {"c":3, "d":4}

d3 = d1.copy()
print ("d1 的信息id是")
print (id(d1))
print ("d3 的信息id是")
print(id(d3))

d3.update(d2)

print (d3)


d1 = {'a': 1, 'b': 2}
d2 = {'c': 3, 'd': 4}
d3 = {**d1, **d2}
print (d3)
# {'a': 1, 'b': 2, 'c': 3, 'd': 4}











