nums = []
print (type(nums))
nums = ()
print (type(nums))
#
nums = (25,19,36,95,14)
#
print (nums)
print (nums[2])
print (nums.index(95))
print (nums[:3])
#
print ('*'*50)
print (nums)
# nums.append(10)
print (nums)
# print (nums.index(36))
# nums.insert(2,8)
# print (nums)
#
# nums.remove(14)
print (list(nums))
print (tuple(list(nums)))


# print ((nums + nums)* 4)
# nums.pop(2)
# print (nums)
# print ('*'*50)
# nums2 = [1,1,1,1]
# nums.extend(nums2)
# print (nums)
# print (nums[5:])
# del nums[5:]
# print (nums)
# print ('*'*50)
# print (nums)
# print(min(nums))
# print(max(nums))
# nums.sort(reverse=True)
# print(nums)
# nums.reverse()
# print(nums)
# print ('*'*50)
# print (len(nums))
# print (nums.count(95))
# nums2 = [1,1,1,1]
# nums.extend(nums2)
# print(nums)
# print (nums.count(1))
# print ('*'*50)
# a ='6'
# print (a)
# print (type(a))
#
#
#
#
#
#
